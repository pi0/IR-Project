#!/usr/bin/env bash
./scripts/run_limit.sh n data/IR_FarsiDatabase.txt data/processed/IR_FarsiDatabase_Normalized.txt  "$@"