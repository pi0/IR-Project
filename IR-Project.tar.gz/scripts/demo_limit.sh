#!/usr/bin/env bash
./scripts/run_limit.sh d data/IR-phase2.txt data/processed/IR-phase2.csv