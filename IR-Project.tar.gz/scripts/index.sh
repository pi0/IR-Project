#!/usr/bin/env bash
./scripts/run.sh i data/processed/IR_FarsiDatabase_Normalized.txt data/processed/index.csv  "$@"