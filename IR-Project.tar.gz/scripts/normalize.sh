#!/usr/bin/env bash
./scripts/run.sh n data/IR_FarsiDatabase.txt data/processed/IR_FarsiDatabase_Normalized.txt  "$@"