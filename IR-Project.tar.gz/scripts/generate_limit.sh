#!/usr/bin/env bash
./scripts/run_limit.sh g data/processed/index.csv  "$@"