#!/usr/bin/env bash
./scripts/run_limit.sh i data/processed/IR_FarsiDatabase_Normalized.txt data/processed/index.csv  "$@"