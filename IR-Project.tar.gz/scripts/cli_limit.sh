#!/usr/bin/env bash
./scripts/run_limit.sh c data/processed/index.csv  "$@"