#!/usr/bin/env bash
./scripts/run.sh c data/processed/index.csv  "$@"