package ir.pi0.irproject.proecessors;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.List;

public class Normalizer extends ir.pi0.irproject.utils.Normalizer {

    public void processArticle(List<String> words, int article_id) {
        throw new NotImplementedException();//...
    }

}
