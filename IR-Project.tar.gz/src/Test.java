import ir.pi0.irproject.repository.QueryResult;
import ir.pi0.irproject.structures.FileBackedLongIntHashMap;
import ir.pi0.irproject.utils.Normalizer;
import ir.pi0.irproject.utils.Util;

import java.io.File;
import java.util.TreeSet;

public class Test {

    public static void main(String[] args) {

//        String b= "هتل ";

//        String s = "می‌رفتم";
//        String s = "هتل ها";
//        String s = "استارت ها";
//        String s = "ماشینی تر";
//        String s = "آمریکاو";
//        String s = "        ساعت";
//        String s = "دولت اتحاد دموكراتيك ملي هند";

//        s= Normalizer.normalize(s);
//
//        Lemmatizer l =new Lemmatizer();
//
//        System.out.println();
//
//        for (String ss:new Tokenizer().tokenize(s)) {
//            String le=l.lemmetize(ss);
//            System.out.print((le == null ? ss : le) + " ");
//        }
//
//        TreeSet<QueryResult> results = new TreeSet();
//
//        results.add(new QueryResult(1,20));
//        results.add(new QueryResult(1,30));
//        results.add(new QueryResult(1,10));
//        results.add(new QueryResult(1,70));
//        results.add(new QueryResult(1,90));
//        results.add(new QueryResult(1,60));
//
//        for (int i = 0; i < 3; i++) {
//            System.out.println(results.pollLast().score);
//        }
//        System.out.println(Normalizer.normalize("ماشینی"));

    }

}
